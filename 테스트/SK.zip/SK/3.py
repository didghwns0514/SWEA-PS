


def solution(width, height, diagonals):
    answer = 0
    return answer

