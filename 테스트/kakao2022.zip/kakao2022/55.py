def findParent(parent, node):
    if parent[node] != node:
        return findParent(parent, parent[node])

    return parent[node]


def isUnionFind(parent, a, b):
    resultA = findParent(parent, a)
    resultB = findParent(parent, b)

    if resultA != resultB:
        return True
    else:
        return False

def solution(commands):
    cellMap = {}
    relationship = {}
    log = []
    for r in range(1, 51):
        for c in range(1, 51):
            cellMap[(r, c)] = ""
            relationship[(r, c)] = (r, c)

    for command in commands:

        if command.startswith("UPDATE") and command.count(' ') == 3:
            _, r, c, value = command.split(' ')
            r, c = int(r), int(c)
            # cellMap[(r, c)] = value
            parentPos = findParent(relationship, (r, c))
            siblings = [
                _key for _key, _value in relationship.items() if _value == parentPos
            ]
            for _key in siblings:
                cellMap[_key] = value

        elif command.startswith("UPDATE") and command.count(' ') == 2:
            _, value1, value2 = command.split(' ')
            for _key, _value in cellMap.items():
                if _value == value1:
                    cellMap[_key] = value2

        elif command.startswith("MERGE"):
            _, r1, c1, r2, c2 = command.split(' ')
            r1, c1, r2, c2 = int(r1), int(c1), int(r2), int(c2)

            if isUnionFind(relationship, (r1, c1), (r2, c2)):

                o1cellValue = cellMap[findParent(relationship, (r1, c1))]
                o2cellValue = cellMap[findParent(relationship, (r2, c2))]
                if o1cellValue != "":
                    parentPos = findParent(relationship, (r1, c1))
                    childPos = findParent(relationship, (r2, c2))
                    siblings = [
                        _key for _key, _value in relationship.items() if _value == childPos
                    ]
                    for _key in siblings:
                        cellMap[_key] = o1cellValue
                        relationship[_key] = parentPos


                elif o1cellValue == "" and o2cellValue != "":
                    parentPos = findParent(relationship, (r2, c2))
                    childPos = findParent(relationship, (r1, c1))
                    siblings = [
                        _key for _key, _value in relationship.items() if _value == childPos
                    ]
                    for _key in siblings:
                        cellMap[_key] = o2cellValue
                        relationship[_key] = parentPos

                else:
                    parentPos = findParent(relationship, (r1, c1))
                    childPos = findParent(relationship, (r2, c2))

                    siblings = [
                        _key for _key, _value in relationship.items() if _value == childPos
                    ]
                    for _key in siblings:
                        cellMap[_key] = o1cellValue
                        relationship[_key] = parentPos

        elif command.startswith("UNMERGE"):
            _, r, c = command.split(' ')
            r, c = int(r), int(c)
            _lookup = findParent(relationship, (r, c))
            siblings = [
              _key  for _key, _value in relationship.items() if _value == _lookup
            ]

            buffMergedValue = cellMap[_lookup]

            for _key in siblings:
                relationship[_key] = _key
                cellMap[_key] = ""

            if buffMergedValue != "":
                cellMap[(r, c)] = buffMergedValue

        elif command.startswith("PRINT"):
            _, r, c = command.split(' ')
            r, c = int(r), int(c)
            if cellMap[(r, c)] == "": log.append("EMPTY")
            else: log.append(cellMap[(r, c)])

    return log



if __name__ == '__main__':
    _type = 2
    if _type == 1:
        commands = ["UPDATE 1 1 menu", "UPDATE 1 2 category", "UPDATE 2 1 bibimbap", "UPDATE 2 2 korean", "UPDATE 2 3 rice", "UPDATE 3 1 ramyeon", "UPDATE 3 2 korean", "UPDATE 3 3 noodle", "UPDATE 3 4 instant", "UPDATE 4 1 pasta", "UPDATE 4 2 italian", "UPDATE 4 3 noodle", "MERGE 1 2 1 3", "MERGE 1 3 1 4", "UPDATE korean hansik", "UPDATE 1 3 group", "UNMERGE 1 4", "PRINT 1 3", "PRINT 1 4"]
        returnValue = solution(commands)
        print(f'returnValue : {returnValue}')
        assert( returnValue == ["EMPTY", "group"])

    elif _type == 2:
        commands = ["UPDATE 1 1 a", "UPDATE 1 2 b", "UPDATE 2 1 c", "UPDATE 2 2 d", "MERGE 1 1 1 2", "MERGE 2 2 2 1",
         "MERGE 2 1 1 1", "PRINT 1 1", "UNMERGE 2 2", "PRINT 1 1"]
        returnValue = solution(commands)
        print(f'returnValue : {returnValue}')
        assert (returnValue == ["d", "Empty"])
