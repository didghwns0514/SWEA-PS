# import sys
# sys.setrecursionlimit(100000)

def checkTree(binString):
    if len(binString) == 3:
        if binString[1] == "0":
            return 0
        else:
            return 1
    elif len(binString) == 1:
        if binString == "0": return 0
        else: return 1


    firstChop = binString[:len(binString) // 2]
    midChop  = binString[len(binString) // 2:(len(binString) // 2) + 1]
    lastChop = binString[(len(binString) // 2) + 1:]

    return checkTree(firstChop) * checkTree(midChop) * checkTree(lastChop)

def solution(numbers):
    answer = []

    for num in numbers:
        # print(f'num : {num}')
        toBinray = bin(num)[2:]
        # print(f'toBinray1 : {toBinray}')
        isOk = True
        if len(toBinray) % 2 == 0: toBinray = "0" + toBinray

        while len(toBinray) > 3:
            pos, ex = toBinray[:3], toBinray[3:]
            toBinray = ex
            # assert(len(pos)==3)
            if pos[1] == "0":
                isOk = False
                break
        else:
            if len(toBinray) in [2, 3] and toBinray[1] == "0":
                isOk = False
        answer.append(int(isOk))
    return answer



if __name__ == '__main__':
    _type = 1
    if _type == 1:
        numbers = [7, 5]
        returnValue = solution(numbers)
        print(f'returnValue : {returnValue}')
        assert( returnValue == [1, 0])

    elif _type == 2:
        numbers = [63, 111, 95]
        returnValue = solution(numbers)
        print(f'returnValue : {returnValue}')
        assert( returnValue == [1, 1, 0])