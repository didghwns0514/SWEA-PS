import itertools

def solution(users, emoticons):
    plusCount = 0
    yeilds = 0

    origin = [10, 20, 30, 40]
    _list = [
        origin for _ in range(len(emoticons))
    ]
    product_list = list(itertools.product(*_list))

    for discounts in product_list:
        tmpPlusCount = 0
        tmpSpent = 0

        for user in users:
            spent = 0
            uDiscount, uBudget = user

            for ie, ePrice in enumerate(emoticons):
                if discounts[ie] >= uDiscount:
                    spent += ePrice * (100 - discounts[ie]) / 100
            if spent >= uBudget:
                tmpPlusCount += 1
            else:
                tmpSpent += spent

            if plusCount == tmpPlusCount and yeilds < tmpSpent:
                yeilds = tmpSpent
            elif tmpPlusCount > plusCount:
                plusCount = tmpPlusCount
                yeilds = tmpSpent


    answer = [plusCount, int(yeilds)]
    return answer

if __name__ == '__main__':
    _type = 2
    if _type == 1:
        users = [[40, 10000], [25, 10000]]
        emoticons = [7000, 9000]
        returnValue = solution(users, emoticons)
        print(f'returnValue : {returnValue}')
        assert( returnValue == [1, 5400])

    elif _type == 2:
        users = [[40, 2900], [23, 10000], [11, 5200], [5, 5900], [40, 3100], [27, 9200], [32, 6900]]
        emoticons = [1300, 1500, 1600, 4900]
        returnValue = solution(users, emoticons)
        print(f'returnValue : {returnValue}')
        assert( returnValue == [4, 13860])