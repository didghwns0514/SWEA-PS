from collections import deque


def getDirection(direction):
    if direction == 0:
        return "r"
    elif direction == 1:
        return "d"
    elif direction == 2:
        return "l"
    elif direction == 3:
        return "u"

def bfs(start, end, n, m, k):
    # x가 세로축
    #    오  아  왼  위
    dx = [0, 1, 0, -1]
    dy = [1, 0, -1, 0]

    fastestOnDictionary = ""
    q = deque()
    visited = []
    interested = []
    q.append( ( start[0], start[1], 0, "" ) )

    while q:
        cx, cy, count, record = q.popleft()

        if count == k and cx == end[0] and cy == end[1]:
            interested.append( (count, record) )
            continue
        elif count > k:
            continue

        # if len(interested) >= 4: break

        # if (cx, cy) not in visited:
        #     visited.append( (cx, cy) )

        for i in range(4):
            ny, nx = cy + dy[i], cx + dx[i]
            if (nx, ny) not in visited and 0 <= nx <= n-1 and 0 <= ny <= m-1:
                if fastestOnDictionary != "":
                    if record + getDirection(i) <= fastestOnDictionary:
                        fastestOnDictionary = record + getDirection(i)
                        q.append((nx, ny, count + 1, record + getDirection(i)))
                else:
                    q.append( (nx, ny, count + 1, record + getDirection(i)) )


    return interested

def solution(n, m, x, y, r, c, k):

    # dataMap = [
    #     [0] * n for _ in range(m)
    # ]
    returnValue = bfs((x-1, y-1), (r-1, c-1), n, m, k)
    if not returnValue:
        return "impossible"
    else:
        return sorted(returnValue)[0][1]


if __name__ == '__main__':
    _type = 3
    if _type == 1:
        n = 3
        m = 4
        x = 2
        y = 3
        r = 3
        c = 1
        k = 5
        result = solution(n, m, x, y, r, c, k)
        print(f'result : {result}')
        assert(result == "dllrl")
    elif _type == 2:
        n = 2
        m = 2
        x = 1
        y = 1
        r = 2
        c = 2
        k = 2
        result = solution(n, m, x, y, r, c, k)
        print(f'result : {result}')
        assert(result == "dr")
    elif _type == 3:
        n = 3
        m = 3
        x = 1
        y = 2
        r = 3
        c = 3
        k = 4
        result = solution(n, m, x, y, r, c, k)
        print(f'result : {result}')
        assert(result == "impossible")
